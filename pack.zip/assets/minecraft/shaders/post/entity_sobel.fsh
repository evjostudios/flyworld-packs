#version 330

#moj_import <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

in vec2 texCoord;

out vec4 fragColor;

// ============================================================================
//  Effect selection by team colour
//
//  Minecraft paints this outline with the entity's scoreboard team colour, and
//  only the 16 legacy chat colours are valid there. That makes the team colour
//  a usable channel: pick a rarely used colour, watch for it here, and paint
//  something vanilla could never draw.
//
//      DARK_AQUA      #00AAAA  ->  pink/cyan gradient, scrolling
//      LIGHT_PURPLE   #FF55FF  ->  breathing pulse, keeps its own hue
//      DARK_PURPLE    #AA00AA  ->  rotating rainbow
//      DARK_GREEN     #00AA00  ->  soft outward halo, self-generated
//
//  Every other team colour is passed through untouched, so ordinary glowing on
//  the server keeps looking ordinary.
//
//  Matching is on HUE, not on the exact value: the five taps below are summed,
//  so brightness varies with how many neighbours contributed while the hue does
//  not. Comparing direction rather than magnitude keeps the test stable.
//
//  PIPELINE NOTE: entity_outline.json runs this shader straight into blit, with
//  NO box-blur passes. That is deliberate - the blur is what produced a thick,
//  soft line, and the wanted look is a crisp one. Two consequences follow, and
//  both are handled below rather than left to chance:
//    - nothing downstream brightens the line, so the colour is renormalised and
//      the alpha hardened with step() at the end;
//    - the halo can no longer borrow the blur's spread, so it builds its own
//      falloff from ring sampling.
//  Re-adding blur passes will soften every effect again.
// ============================================================================

const float TOLERANCE = 0.25;

// Alpha below this is not treated as an edge. Raising it thins the line and
// drops stray pixels; lowering it thickens the line and lets faint edges in.
const float EDGE_CUTOFF = 0.30;

const vec3 KEY_GRADIENT = vec3(0.000, 0.667, 0.667);  // DARK_AQUA
const vec3 KEY_PULSE    = vec3(1.000, 0.333, 1.000);  // LIGHT_PURPLE
const vec3 KEY_RAINBOW  = vec3(0.667, 0.000, 0.667);  // DARK_PURPLE
const vec3 KEY_HALO     = vec3(0.000, 0.667, 0.000);  // DARK_GREEN

// --- Tuning ---
const vec3  GRADIENT_A     = vec3(1.0, 0.15, 0.75);  // neon pink
const vec3  GRADIENT_B     = vec3(0.0, 0.95, 1.0);   // neon cyan
const float GRADIENT_BANDS = 8.0;   // pink->cyan cycles across the screen diagonal
const float GRADIENT_SPEED = 600.0; // how fast those bands travel

const float PULSE_SPEED    = 900.0; // breaths per unit of GameTime
const float PULSE_FLOOR    = 0.25;  // dimmest point of the breath, 0..1

const float RAINBOW_SPEED  = 400.0;
const float RAINBOW_SPREAD = 1.5;   // how much hue shifts along the outline

const float HALO_SPEED     = 500.0;
const float HALO_FLOOR     = 0.45;
// How far out the halo reaches, in texels. This shader builds its own falloff
// by sampling a ring at this radius, so the number is a real distance rather
// than a multiplier - raising it widens the glow and costs HALO_SAMPLES more
// texture reads at that radius.
const float HALO_RADIUS    = 5.0;
// Points around the ring. Too few and the halo breaks into visible spokes on a
// large silhouette; more than this buys nothing the eye can see.
const int   HALO_SAMPLES   = 12;
// Peak opacity of the halo. Kept below 1.0 so it reads as a glow bleeding off
// the silhouette rather than a second hard band around it.
const float HALO_STRENGTH  = 0.65;

// GameTime wraps every 24000 ticks; multiplying it is the idiom vanilla itself
// uses for animation, so keep the speed constants large.
float wave(float speed) {
    return sin(GameTime * speed);
}

bool matches(vec3 c, vec3 key) {
    float m = max(max(c.r, c.g), c.b);
    if (m < 0.001) {
        return false;
    }
    return distance(c / m, key / max(max(key.r, key.g), key.b)) < TOLERANCE;
}

// Coverage of the silhouette on a ring HALO_RADIUS texels out from this pixel.
//
// The halo has to exist OUTSIDE the entity, where the sobel edge test returns
// nothing, so it cannot be derived from that edge at all. Instead it asks a
// different question: how much of the entity is near me? A pixel just off the
// silhouette has most of the ring inside it and glows brightly; one further out
// catches less of it and fades. That is the falloff, generated here rather than
// inherited from a blur pass.
float ringCoverage(vec2 uv, vec2 oneTexel) {
    float hits = 0.0;
    for (int i = 0; i < HALO_SAMPLES; i++) {
        float angle = 6.2831853 * float(i) / float(HALO_SAMPLES);
        vec2 offset = vec2(cos(angle), sin(angle)) * HALO_RADIUS * oneTexel;
        hits += texture(InSampler, uv + offset).a;
    }
    return hits / float(HALO_SAMPLES);
}

// The colour carried by the silhouette near this pixel.
//
// ringCoverage answers "how much", this answers "what colour". Outside the
// entity center.rgb is black, so the halo branch would never match its key
// colour without this. Samples are premultiplied by alpha and normalised by the
// alpha actually collected, so an empty ring returns black and fails the match.
vec3 ringColor(vec2 uv, vec2 oneTexel) {
    vec3 sum = vec3(0.0);
    float weight = 0.0;
    for (int i = 0; i < HALO_SAMPLES; i++) {
        float angle = 6.2831853 * float(i) / float(HALO_SAMPLES);
        vec2 offset = vec2(cos(angle), sin(angle)) * HALO_RADIUS * oneTexel;
        vec4 s = texture(InSampler, uv + offset);
        sum += s.rgb * s.a;
        weight += s.a;
    }
    return weight > 0.001 ? sum / weight : vec3(0.0);
}

// Cheap HSV->RGB for the rainbow. Hue in turns (0..1), full saturation.
vec3 hueToRgb(float h) {
    vec3 k = mod(vec3(5.0, 3.0, 1.0) + h * 6.0, 6.0);
    return clamp(min(k, 4.0 - k), 0.0, 1.0);
}

void main(){
    vec2 oneTexel = 1.0 / InSize;

    vec4 center = texture(InSampler, texCoord);
    vec4 left = texture(InSampler, texCoord - vec2(oneTexel.x, 0.0));
    vec4 right = texture(InSampler, texCoord + vec2(oneTexel.x, 0.0));
    vec4 up = texture(InSampler, texCoord - vec2(0.0, oneTexel.y));
    vec4 down = texture(InSampler, texCoord + vec2(0.0, oneTexel.y));

    // Edge = change in alpha across the four neighbours. This is what keeps the
    // result an outline: testing "has alpha" instead would mark the entity's
    // whole surface and fill the silhouette in solid.
    float leftDiff  = abs(center.a - left.a);
    float rightDiff = abs(center.a - right.a);
    float upDiff    = abs(center.a - up.a);
    float downDiff  = abs(center.a - down.a);
    float total = clamp(leftDiff + rightDiff + upDiff + downDiff, 0.0, 1.0);

    // Five premultiplied taps summed and scaled back by 0.2 - their average.
    // Dropping the 0.2 blows the colour out to white.
    vec3 outColor = center.rgb * center.a + left.rgb * left.a + right.rgb * right.a
                  + up.rgb * up.a + down.rgb * down.a;
    outColor *= 0.2;

    // A diagonal sweep in screen space. An entity covers a small slice of the
    // viewport, so a single sweep would land its whole outline on one colour;
    // scaling by BANDS repeats it so the full range shows on one entity.
    float sweep = (texCoord.x + texCoord.y) * 0.5;

    // Set by any branch that drives its own alpha, so the crisp-edge hardening
    // at the bottom leaves that animation alone.
    bool custom = false;

    // The halo is the one effect that must paint pixels the sobel rejected: it
    // lives outside the silhouette, where every diff above is zero and outColor
    // is black. So it gets its own colour probe and its own coverage, sampled
    // from the ring rather than from the four edge neighbours, and its branch is
    // tested against THAT colour instead of the edge colour.
    float coverage = ringCoverage(texCoord, oneTexel);
    vec3 haloColor = center.a > 0.001 ? center.rgb : ringColor(texCoord, oneTexel);

    if (matches(outColor, KEY_GRADIENT)) {
        float t = sweep * GRADIENT_BANDS - GameTime * GRADIENT_SPEED;
        outColor = mix(GRADIENT_A, GRADIENT_B, abs(fract(t) * 2.0 - 1.0));

    } else if (matches(outColor, KEY_PULSE)) {
        // Breathes on ALPHA, not on colour.
        //
        // Scaling outColor looks like almost nothing here: the outline is a thin
        // line over transparency, so what the eye reads is its opacity, not the
        // luminance of its RGB. The sobel sum above is already scaled by 0.2, so
        // dimming the colour further just walks it toward black instead of
        // fading it out. Alpha is the channel that actually shows.
        //
        // The colour is also lifted to full brightness first, so the pulse peaks
        // as a bright line rather than a muddy one.
        outColor = normalize(max(outColor, vec3(0.001)));
        total = step(EDGE_CUTOFF, total) * mix(PULSE_FLOOR, 1.0, wave(PULSE_SPEED) * 0.5 + 0.5);
        custom = true;

    } else if (matches(outColor, KEY_RAINBOW)) {
        outColor = hueToRgb(fract(GameTime * RAINBOW_SPEED + sweep * RAINBOW_SPREAD));

    } else if (matches(haloColor, KEY_HALO)) {
        // Built from ring coverage, not from the sobel edge.
        //
        // Every other effect repaints the edge the sobel found. A halo has to
        // live OUTSIDE the silhouette, where that edge is blank, so it is
        // generated here instead: coverage falls off with distance, and that
        // falloff IS the glow. This used to lean on two box-blur passes to
        // spread a boosted edge outward; those passes are gone, so the shape
        // is produced locally and the effect no longer depends on them.
        outColor = normalize(max(haloColor, vec3(0.001)));

        // Raw coverage alone would FILL THE ENTITY: deep inside the silhouette
        // the whole ring is covered, so coverage is 1.0 and the mob turns into
        // a solid blob. Subtracting the pixel's own alpha is what keeps this a
        // halo - it cancels wherever the entity itself is already drawn, and
        // survives only in the band just outside the edge, where the ring still
        // reaches the silhouette but this pixel is empty.
        float halo = clamp(coverage - center.a, 0.0, 1.0);
        total = halo * HALO_STRENGTH
              * mix(HALO_FLOOR, 1.0, wave(HALO_SPEED) * 0.5 + 0.5);
        custom = true;
    }

    // The sobel sum above was averaged by 0.2, so the line comes out darker than
    // the team colour it was drawn from. With the blur passes removed there is
    // nothing downstream to hide that, so the colour is lifted back to full
    // brightness - this is what makes the line read as solid neon rather than a
    // muddy tint.
    outColor = outColor / max(max(max(outColor.r, outColor.g), outColor.b), 0.001);

    // Partial edges leave a soft alpha ramp, which reads as a see-through line.
    // step() collapses that ramp into a hard on/off edge. Branches that animate
    // their own alpha already applied their cutoff and are skipped here, so this
    // hardening never overwrites their breathing.
    if (!custom) {
        total = step(EDGE_CUTOFF, total);
    }

    fragColor = vec4(outColor, total);
}
