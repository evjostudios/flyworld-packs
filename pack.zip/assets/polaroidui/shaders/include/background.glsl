// polaroidui:background v2
//
// PolaroidUI dialog backgrounds. PolaroidUI ships this file as
// assets/polaroidui/shaders/include/background.glsl, generated from DialogBackground.
//
// A text vertex shader imports it like polaroidui:anchor.glsl and calls it last, once
// gl_Position and vertexColor are set, with the client's vertex index (gl_VertexID, or
// gl_VertexIndex from 26.3):
//     polaroiduiBackground(ProjMat, Color, gl_VertexID, gl_Position, vertexColor);
//
// Marker colors (0 to 255): red 70, green the opacity in percent (0 to 100), blue
// 28 plus the style id (0 to 3). polaroiduiBackgroundStyle tells a shader that draws
// styles of its own which one a vertex has.

#ifndef POLAROIDUI_BACKGROUND
#define POLAROIDUI_BACKGROUND

// Red of every marker. Above 64, so no text shadow has a marker color.
const float POLAROIDUI_BACKGROUND_RED = 70.0;
// Blue of style 0; styles 0 to 3 are reserved.
const float POLAROIDUI_BACKGROUND_BLUE = 28.0;
// The color the background covers the screen with.
const vec3 POLAROIDUI_BACKGROUND_DARK = vec3(0.02, 0.016, 0.035);
// Alpha (0 to 255) of the cover glyph's only pixel, below the fragment shader's cutoff.
const float POLAROIDUI_BACKGROUND_PIXEL_ALPHA = 1.0;

// The style id (0 to 3) of a GUI text vertex of a marker color, or -1 for any other.
int polaroiduiBackgroundStyle(mat4 projMat, vec4 color) {
    // Perspective (world text: signs, name tags) has projMat[2][3] == -1.
    if (projMat[2][3] != 0.0 || projMat[0][0] == 0.0 || projMat[1][1] == 0.0) {
        return -1;
    }
    vec3 rgb = floor(color.rgb * 255.0 + 0.5);
    if (rgb.r != POLAROIDUI_BACKGROUND_RED || rgb.g > 100.0
            || rgb.b < POLAROIDUI_BACKGROUND_BLUE || rgb.b > POLAROIDUI_BACKGROUND_BLUE + 3.0) {
        return -1;
    }
    return int(rgb.b - POLAROIDUI_BACKGROUND_BLUE);
}

// The opacity (0 to 1) of a marker color.
float polaroiduiBackgroundOpacity(vec4 color) {
    return floor(color.g * 255.0 + 0.5) / 100.0;
}

// Stretches a GUI text quad of a marker color over the whole screen, in the background
// color at the marker's opacity. Glyph quads are drawn top left, bottom left, bottom
// right, top right.
void polaroiduiBackground(mat4 projMat, vec4 color, int vertexId, inout vec4 position,
        inout vec4 vertexColor) {
    if (polaroiduiBackgroundStyle(projMat, color) < 0) {
        return;
    }
    int corner = vertexId % 4;
    vec2 edge = vec2(corner < 2 ? -1.0 : 1.0, corner == 0 || corner == 3 ? -1.0 : 1.0);
    // Each axis flips like the projection flips it, so the quad keeps its winding.
    edge *= vec2(sign(projMat[0][0]), sign(projMat[1][1]));
    position = vec4(edge * position.w, position.z, position.w);
    vertexColor = vec4(POLAROIDUI_BACKGROUND_DARK, polaroiduiBackgroundOpacity(color)
            * color.a * 255.0 / POLAROIDUI_BACKGROUND_PIXEL_ALPHA);
}

#endif
