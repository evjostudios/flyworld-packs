// polaroidui:anchor contract v1
//
// PolaroidUI screen anchors, shared contract. PolaroidUI ships this file as
// assets/polaroidui/shaders/include/anchor.glsl, and PolaroidShaders (AnimatedChat) ships
// the identical file. Keep it byte-identical in both repositories: PolaroidUI generates it
// from ScreenAnchor, so change it there and copy the result.
//
// A rendertype_text vertex shader imports it as moj_import <polaroidui:anchor.glsl> and
// applies it right after ModelViewMat:
//     gl_Position = ProjMat * polaroiduiAnchor(ProjMat, ModelViewMat * vec4(Position, 1.0));

#ifndef POLAROIDUI_ANCHOR
#define POLAROIDUI_ANCHOR

const float POLAROIDUI_BASE = 16384.0;
const float POLAROIDUI_BAND = 2048.0;
const float POLAROIDUI_ROW_RESERVE = 512.0;

// Moves a GUI text vertex that was pushed into an anchor band to its anchor.
vec4 polaroiduiAnchor(mat4 projMat, vec4 view) {
    // Perspective (world text: signs, name tags) has projMat[2][3] == -1.
    if (projMat[2][3] != 0.0 || projMat[0][0] == 0.0 || projMat[1][1] == 0.0) {
        return view;
    }
    float width = abs(2.0 / projMat[0][0]);
    float height = abs(2.0 / projMat[1][1]);
    float encoded = view.x - width * 0.5 - POLAROIDUI_BASE;
    if (encoded < -POLAROIDUI_BAND * 0.5) {
        return view;
    }
    float anchor = floor(encoded / POLAROIDUI_BAND + 0.5);
    if (anchor > 8.0) {
        return view;
    }
    float offset = encoded - anchor * POLAROIDUI_BAND;
    float column = mod(anchor, 3.0);
    float row = floor(anchor / 3.0);
    view.x = column < 0.5 ? offset : (column < 1.5 ? width * 0.5 + offset : width + offset);
    if (row > 1.5) {
        view.y += height - POLAROIDUI_ROW_RESERVE;
    } else if (row > 0.5) {
        view.y += height * 0.5 - POLAROIDUI_ROW_RESERVE * 0.5;
    }
    return view;
}

#endif
