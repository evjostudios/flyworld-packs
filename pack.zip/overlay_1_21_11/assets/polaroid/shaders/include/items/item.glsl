// (c) 2026 PolaroidStudio. All rights reserved. Unauthorized copying or redistribution is prohibited. See LICENSE.
#moj_import <minecraft:globals.glsl>
#moj_import <polaroid:items/contract.glsl>
#moj_import <polaroid:items/effects.glsl>
const float l11lI=1200.0;vec4 Il0lI(vec4 O1Ol){return O1Ol;}vec4 ll0lI(vec4 I10lI,vec4 O00lI,vec4 IIlII,vec2 II10,vec2 l00lI){float O11lI=round(O00lI.a*255.0);if(!I1OlI(O11lI)){return I10lI;}vec3 O1Ol=O00lI.rgb*ColorModulator.rgb;vec3 I11lI=lOOlI(floor(O00lI.rgb*255.0+0.5))*IIlII.rgb;vec3 l1lO=I01lI(O11lI,O1Ol,I11lI,II10*l00lI,GameTime*l11lI);return vec4(l1lO,1.0);}
