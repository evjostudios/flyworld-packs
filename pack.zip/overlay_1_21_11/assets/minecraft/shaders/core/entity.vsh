#version 330
// (c) 2026 PolaroidStudio. All rights reserved. Unauthorized copying or redistribution is prohibited. See LICENSE.
#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
in vec3 Position;in vec4 Color;in vec2 UV0;in ivec2 UV1;in ivec2 UV2;in vec3 Normal;uniform sampler2D Sampler0;uniform sampler2D Sampler1;uniform sampler2D Sampler2;out float I1I0;out float Il0l;
#ifdef PER_FACE_LIGHTING
out vec4 lOl0I;out vec4 IOl0I;
#else 
out vec4 lO10;
#endif 
out vec4 l11OI;out vec4 O01OI;out vec2 O0I0;flat out vec4 O0OOI;
#moj_import <polaroid:portrait/theme.glsl>
void main(){vec3 position=Position;
#ifdef PER_FACE_LIGHTING
vec2 O0lII=minecraft_compute_light(Light0_Direction,Light1_Direction,Normal);lOl0I=minecraft_mix_light_separate(-O0lII,Color);IOl0I=minecraft_mix_light_separate(O0lII,Color);
#elif defined(NO_CARDINAL_LIGHTING)
lO10=Color;
#else 
lO10=minecraft_mix_light(Light0_Direction,Light1_Direction,Normal,Color);
#endif 
#ifndef EMISSIVE
l11OI=texelFetch(Sampler2,UV2/16,0);
#endif 
O01OI=texelFetch(Sampler1,UV1,0);O0OOI=vec4(-1.0);O0I0=UV0;if(l1OOI(Position)){int I10OI=(gl_VertexID/4)%24;if(I10OI==2||I10OI==4){int l1III=gl_VertexID%4;vec2 II10=vec2((l1III==0||l1III==3)?1.0:0.0,l1III>1?1.0:0.0);vec2 l10OI=(II10*vec2(1.0,70.0/79.0)+vec2(0.0,9.0/79.0))*(2.0/vec2(ProjMat[0][0],-ProjMat[1][1]));O0I0=II10;position.xy=round(l10OI);O0OOI=vec4(OlOOI(),1.0);}else{position=vec3(0.0);}}gl_Position=ProjMat*ModelViewMat*vec4(position,1.0);I1I0=fog_spherical_distance(position);Il0l=fog_cylindrical_distance(position);
#ifdef APPLY_TEXTURE_MATRIX
O0I0=(TextureMat*vec4(O0I0,0.0,1.0)).xy;
#endif 
}
