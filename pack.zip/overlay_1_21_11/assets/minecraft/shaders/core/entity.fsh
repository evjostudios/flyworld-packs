#version 330
// (c) 2026 PolaroidStudio. All rights reserved. Unauthorized copying or redistribution is prohibited. See LICENSE.
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
uniform sampler2D Sampler0;in float I1I0;in float Il0l;
#ifdef PER_FACE_LIGHTING
in vec4 lOl0I;in vec4 IOl0I;
#else 
in vec4 lO10;
#endif 
in vec4 l11OI;in vec4 O01OI;in vec2 O0I0;flat in vec4 O0OOI;out vec4 fragColor;
#moj_import <polaroid:portrait/render.glsl>
void main(){if(O0OOI.w>0.0){fragColor=lOOOI(O0I0,O0OOI.rgb);return;}vec4 O1Ol=texture(Sampler0,O0I0);
#ifdef ALPHA_CUTOUT
if(O1Ol.a<ALPHA_CUTOUT){discard;}
#endif 
#ifdef PER_FACE_LIGHTING
O1Ol*=(gl_FrontFacing?IOl0I:lOl0I)*ColorModulator;
#else 
O1Ol*=lO10*ColorModulator;
#endif 
#ifndef NO_OVERLAY
O1Ol.rgb=mix(O01OI.rgb,O1Ol.rgb,O01OI.a);
#endif 
#ifndef EMISSIVE
O1Ol*=l11OI;
#endif 
fragColor=apply_fog(O1Ol,I1I0,Il0l,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}
