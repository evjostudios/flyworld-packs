#version 330
// (c) 2026 PolaroidStudio. All rights reserved. Unauthorized copying or redistribution is prohibited. See LICENSE.
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
uniform sampler2D Sampler0;in vec4 lO10;in vec2 O0I0;out vec4 fragColor;void main(){vec4 O1Ol=texture(Sampler0,O0I0);if(O1Ol.a==0.0){discard;}vec3 l1lO=ColorModulator.rgb*lO10.rgb;if((ivec3(floor(lO10.rgb*255.0+0.5))&3)==ivec3(2,1,2)){l1lO*=0.35+0.65*(0.5+0.5*sin(GameTime*1200.0*12.0));}fragColor=vec4(l1lO,ColorModulator.a);}
