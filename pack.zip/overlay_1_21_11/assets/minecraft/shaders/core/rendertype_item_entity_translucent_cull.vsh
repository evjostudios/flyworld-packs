#version 330
// (c) 2026 PolaroidStudio. All rights reserved. Unauthorized copying or redistribution is prohibited. See LICENSE.
#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <polaroid:items/item.glsl>
#moj_import <polaroid:items/dissolve.glsl>
#moj_import <polaroid:items/finish.glsl>
in vec3 Position;in vec4 Color;in vec2 UV0;in vec2 UV1;in ivec2 UV2;in vec3 Normal;uniform sampler2D Sampler2;out float I1I0;out float Il0l;out vec4 lO10;out vec4 II0lI;out vec2 O0I0;out vec2 OllII;out vec2 lIlII;flat out vec4 IOI1I;flat out float lI11I;out vec4 ll11I;void main(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);I1I0=fog_spherical_distance(Position);Il0l=fog_cylindrical_distance(Position);IOI1I=O1I1I(Color);lI11I=float(l111I(Color));ll11I=I111I(gl_VertexID,ProjMat,ModelViewMat,Position,Normal);vec4 OI1II=IOI1I.w>0.5||lI11I>=0.0?vec4(1.0,1.0,1.0,Color.a):Color;lO10=minecraft_mix_light(Light0_Direction,Light1_Direction,Normal,OI1II)*texelFetch(Sampler2,UV2/16,0);II0lI=Il0lI(OI1II);O0I0=UV0;OllII=UV1;lIlII=UV2;}
