#version 330
// (c) 2026 PolaroidStudio. All rights reserved. Unauthorized copying or redistribution is prohibited. See LICENSE.
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <polaroid:items/item.glsl>
#moj_import <polaroid:items/dissolve.glsl>
#moj_import <polaroid:items/finish.glsl>
uniform sampler2D Sampler0;in float I1I0;in float Il0l;in vec4 lO10;in vec4 II0lI;in vec2 O0I0;in vec2 OllII;flat in vec4 IOI1I;flat in float lI11I;in vec4 ll11I;out vec4 fragColor;void main(){vec4 O00lI=texture(Sampler0,O0I0);vec4 O1Ol=O00lI*lO10*ColorModulator;if(O1Ol.a<0.1){discard;}O1Ol=ll0lI(O1Ol,O00lI,II0lI,O0I0,vec2(textureSize(Sampler0,0)));O1Ol.rgb=O0I1I(O1Ol.rgb,int(floor(lI11I+0.5)),ll11I,O0I0,vec2(textureSize(Sampler0,0)),GameTime*l11lI);float l1I1I=I1I1I(IOI1I,O0I0,vec2(textureSize(Sampler0,0)));if(l1I1I<0.0){discard;}if(l1I1I>0.0){O1Ol=vec4(III1I[int(IOI1I.z+0.5)],1.0);}fragColor=apply_fog(O1Ol,I1I0,Il0l,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}
