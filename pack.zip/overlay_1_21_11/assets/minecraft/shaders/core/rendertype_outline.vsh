#version 330
// (c) 2026 PolaroidStudio. All rights reserved. Unauthorized copying or redistribution is prohibited. See LICENSE.
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
in vec3 Position;in vec4 Color;in vec2 UV0;out vec4 lO10;out vec2 O0I0;void main(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);lO10=Color;O0I0=UV0;}
